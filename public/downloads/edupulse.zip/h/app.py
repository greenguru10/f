import streamlit as st
import folium
from streamlit_folium import st_folium
from folium.plugins import Draw, MeasureControl, MiniMap
from geopy.geocoders import Nominatim
import pandas as pd
import numpy as np
from datetime import datetime
import requests
import time
from functools import wraps
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.impute import SimpleImputer
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import matplotlib.pyplot as plt
import seaborn as sns
import os

# =================================================================
# CONFIGURATION
# =================================================================
API_KEY = "31b7a7d12ce49d1f692866ab73c7d1bf"

SOIL_DATABASE = {
    'Andhra Pradesh': {
        'soil_texture': 'Red Sandy', 
        'soil_Type': 'Sandy_Loam',
        'clay': 15.0, 
        'sand': 70.0, 
        'silt': 15.0, 
        'organic_carbon': 0.5,
        'ph': 6.5,
        'fertility': 'Medium',
        'soil_Humidity': 'Moderate',
        'soil_Temp': 30
    },
    'default': {
        'soil_texture': 'Loam', 
        'soil_Type': 'Loam',
        'clay': 20.0, 
        'sand': 40.0, 
        'silt': 40.0, 
        'organic_carbon': 1.0,
        'ph': 7.0,
        'fertility': 'High',
        'soil_Humidity': 'Moderate',
        'soil_Temp': 25
    }
}

REGION_BOUNDARIES = {
    'Andhra Pradesh': (12.6, 19.2, 76.8, 84.6),
}

# =================================================================
# AUTHENTICATION
# =================================================================
USERS = {
    "gov_user": {"password": "gov123", "user_type": "government", "organization": "Forest Department"},
    "ngo_user": {"password": "ngo123", "user_type": "ngo", "organization": "Green Earth NGO"},
    "user1": {"password": "user123", "user_type": "individual", "organization": None}
}

def authenticate_user(username, password):
    user = USERS.get(username)
    if user and user['password'] == password:
        return {
            'username': username,
            'user_type': user['user_type'],
            'organization': user['organization']
        }
    return None

def login_required(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        if 'user' not in st.session_state:
            st.warning("Please login to access this page.")
            return
        return func(*args, **kwargs)
    return wrapper

# =================================================================
# CORE FUNCTIONS
# =================================================================
def get_climate_zone(lat):
    """Determine climate zone based on latitude"""
    if abs(lat) < 23.5:
        return 'tropical'
    elif abs(lat) < 66.5:
        return 'temperate'
    else:
        return 'arctic'

def get_region_from_coords(lat, lon):
    """Get region from coordinates"""
    for region, bounds in REGION_BOUNDARIES.items():
        if bounds[0] <= lat <= bounds[1] and bounds[2] <= lon <= bounds[3]:
            return region
    return get_climate_zone(lat)

def get_soil_data(lat, lon):
    """Get soil data from offline database"""
    region = get_region_from_coords(lat, lon)
    return SOIL_DATABASE.get(region, SOIL_DATABASE['default'])

def get_weather_data(lat, lon):
    """Get weather data from OpenWeatherMap API"""
    url = f"http://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={API_KEY}&units=metric"
    try:
        response = requests.get(url, timeout=10)
        if response.status_code == 200:
            data = response.json()
            return {
                "temperature": data["main"]["temp"],
                "humidity": data["main"]["humidity"]
            }
    except Exception as e:
        st.error(f"Weather API error: {str(e)}")
    return None

def calculate_ndvi(lat, lon):
    """Simulate NDVI calculation (replace with actual NDVI calculation in production)"""
    base_value = 0.3 + (abs(lat) / 90) * 0.6  # Ranges from 0.3 to 0.9
    return np.clip(base_value + np.random.normal(0, 0.1), 0, 1)

def get_land_health_status(ndvi):
    """Determine land health based on NDVI value"""
    if ndvi > 0.6:
        return "Healthy 🌿", "#2E7D32", "#E8F5E9"  # Dark green, light green
    elif ndvi > 0.3:
        return "Moderate ⚠️", "#FF8F00", "#FFF3E0"  # Orange, light orange
    else:
        return "Degraded 🔥", "#C62828", "#FFEBEE"  # Red, light red

# =================================================================
# TREE RECOMMENDATION SYSTEM WITH CLUSTERING AND GBM
# =================================================================
@st.cache_data
def load_and_cluster_tree_data():
    """Load tree data, clean it, and perform clustering"""
    try:
        # Load the dataset
        df = pd.read_csv("Finaltrees1.csv")
        
        # Clean column names
        df.columns = df.columns.str.strip()
        
        # Process temperature (convert ranges to averages and handle missing values)
        def process_temp(temp):
            if pd.isna(temp):
                return np.nan
            if isinstance(temp, str):
                temp = temp.replace('°C', '').strip()
                if '-' in temp:
                    low, high = temp.split('-')
                    return (float(low.strip()) + float(high.strip())) / 2
                return float(temp)
            return float(temp)
        
        df['Temp_avg'] = df['Favourable Temperature'].apply(process_temp)
        
        # Impute missing temperature values with median
        temp_median = df['Temp_avg'].median()
        df['Temp_avg'].fillna(temp_median, inplace=True)
        
        # Encode humidity with handling for missing values
        humidity_map = {'Low': 0, 'Moderate': 1, 'High': 2}
        df['Humidity_encoded'] = df['Humidity'].map(humidity_map)
        
        # Impute missing humidity values with mode (most frequent)
        humidity_mode = df['Humidity_encoded'].mode()[0]
        df['Humidity_encoded'].fillna(humidity_mode, inplace=True)
        
        # One-hot encode soil types with handling for missing values
        df['Soil Type'].fillna('Unknown', inplace=True)
        df = pd.get_dummies(df, columns=['Soil Type'], prefix='Soil')
        
        # Features for clustering
        features = ['Temp_avg', 'Humidity_encoded'] + [col for col in df.columns if col.startswith('Soil_')]
        X = df[features]
        
        # Scale features
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
        
        # Perform clustering
        kmeans = KMeans(n_clusters=5, random_state=42)
        df['Cluster'] = kmeans.fit_predict(X_scaled)
        
        return df, kmeans, scaler, features
        
    except Exception as e:
        st.error(f"Error loading tree data: {str(e)}")
        # Return sample data if there's an error
        sample_data = {
            'Accepted name': ['Neem', 'Banyan', 'Mango', 'Teak', 'Bamboo'],
            'Family': ['Meliaceae', 'Moraceae', 'Anacardiaceae', 'Lamiaceae', 'Poaceae'],
            'Temp_avg': [25, 25, 30, 30, 22.5],
            'Humidity_encoded': [1, 2, 1, 1, 2],
            'Soil_Clay': [0, 1, 0, 0, 0],
            'Soil_Loam': [1, 0, 1, 1, 0],
            'Soil_Sandy': [0, 0, 0, 0, 1]
        }
        df = pd.DataFrame(sample_data)
        features = ['Temp_avg', 'Humidity_encoded', 'Soil_Clay', 'Soil_Loam', 'Soil_Sandy']
        scaler = StandardScaler().fit(df[features])
        kmeans = KMeans(n_clusters=3, random_state=42).fit(scaler.transform(df[features]))
        df['Cluster'] = kmeans.labels_
        return df, kmeans, scaler, features

class SafeLabelEncoder(LabelEncoder):
    """LabelEncoder that handles unseen labels by assigning them to a special category"""
    def __init__(self, unknown_label=-1):
        self.unknown_label = unknown_label
        super().__init__()
    
    def transform(self, y):
        try:
            return super().transform(y)
        except ValueError:
            return np.array([self.unknown_label if x not in self.classes_ else self.classes_.tolist().index(x) for x in y])

@st.cache_data
def load_co2_data():
    """Load the CO2 sequestration data"""
    try:
        # Try both possible filenames
        try:
            df = pd.read_csv("co2_data.csv")
        except FileNotFoundError:
            df = pd.read_csv("updated_file (1).csv")
        
        # Clean column names
        df.columns = df.columns.str.strip()
        
        # Convert temperature to numeric (assuming it's in °C)
        df['Favourable temperature'] = df['Favourable temperature'].str.replace('°C', '').astype(float)
        
        # Encode categorical variables with safe handling
        le_family = SafeLabelEncoder()
        le_species = SafeLabelEncoder()
        le_soil = SafeLabelEncoder()
        le_humidity = SafeLabelEncoder()
        
        # Fit with all possible categories
        all_families = ['Meliaceae', 'Moraceae', 'Anacardiaceae', 'Lamiaceae', 'Poaceae', 'Pinaceae']
        le_family.fit(all_families)
        
        all_species = ['Azadirachta indica', 'Ficus benghalensis', 'Mangifera indica', 
                      'Tectona grandis', 'Bambusoideae', 'Abies chensiensis']
        le_species.fit(all_species)
        
        all_soil = ['Loam', 'Clay', 'Sandy', 'Sandy_Loam', 'Unknown']
        le_soil.fit(all_soil)
        
        all_humidity = ['Low', 'Moderate', 'High']
        le_humidity.fit(all_humidity)
        
        # Transform data
        df['Tree Family Encoded'] = le_family.transform(df['Tree Family'])
        df['Scientific Name Encoded'] = le_species.transform(df['Scientific Name'])
        df['Soil Type Encoded'] = le_soil.transform(df['Soil Type'])
        df['Soil Humidity Encoded'] = le_humidity.transform(df['Soil Humidity'])
        
        return df, le_family, le_species, le_soil, le_humidity
    except Exception as e:
        st.error(f"Error loading CO2 data: {str(e)}")
        # Return sample data if there's an error
        sample_data = {
            'Tree Family': ['Meliaceae', 'Moraceae', 'Anacardiaceae', 'Lamiaceae', 'Poaceae', 'Pinaceae'],
            'Scientific Name': ['Azadirachta indica', 'Ficus benghalensis', 'Mangifera indica', 
                              'Tectona grandis', 'Bambusoideae', 'Abies chensiensis'],
            'Favourable temperature': [30, 25, 30, 25, 22, 20],
            'Soil Type': ['Loam', 'Clay', 'Loam', 'Sandy', 'Sandy_Loam', 'Loam'],
            'Soil Humidity': ['Moderate', 'High', 'Moderate', 'Moderate', 'High', 'Moderate'],
            'Soil Temperature': [28, 26, 28, 30, 24, 22],
            'CO2 Absorption (kg/year)': [48.5, 60.3, 42.1, 38.7, 35.2, 45.0],
            'CO2 Decrease After Years (kg)': [2.5, 3.2, 2.1, 1.9, 1.5, 2.0]
        }
        df = pd.DataFrame(sample_data)
        
        # Encode categorical variables for sample data
        le_family = SafeLabelEncoder()
        le_species = SafeLabelEncoder()
        le_soil = SafeLabelEncoder()
        le_humidity = SafeLabelEncoder()
        
        # Fit with all possible categories
        le_family.fit(sample_data['Tree Family'])
        le_species.fit(sample_data['Scientific Name'])
        le_soil.fit(sample_data['Soil Type'])
        le_humidity.fit(sample_data['Soil Humidity'])
        
        # Transform data
        df['Tree Family Encoded'] = le_family.transform(df['Tree Family'])
        df['Scientific Name Encoded'] = le_species.transform(df['Scientific Name'])
        df['Soil Type Encoded'] = le_soil.transform(df['Soil Type'])
        df['Soil Humidity Encoded'] = le_humidity.transform(df['Soil Humidity'])
        
        return df, le_family, le_species, le_soil, le_humidity

@st.cache_data
def train_co2_model(df):
    """Train the GBM model for CO2 prediction"""
    try:
        # Features and target
        features = ['Tree Family Encoded', 'Scientific Name Encoded', 'Favourable temperature', 
                   'Soil Type Encoded', 'Soil Humidity Encoded', 'Soil Temperature']
        target = 'CO2 Absorption (kg/year)'
        
        X = df[features]
        y = df[target]
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        # Train GBM model
        gbm = GradientBoostingRegressor(n_estimators=100, learning_rate=0.1, 
                                     max_depth=3, random_state=42)
        gbm.fit(X_train, y_train)
        
        # Evaluate
        y_pred = gbm.predict(X_test)
        mse = mean_squared_error(y_test, y_pred)
        
        return gbm, mse, features
    except Exception as e:
        st.error(f"Error training CO2 model: {str(e)}")
        return None, None, None

def predict_co2_sequestration(model, tree_data, years=5):
    """Predict CO2 sequestration for next 5 years"""
    try:
        # Prepare input data for prediction
        input_data = tree_data.copy()
        
        # Predict for each year considering the decrease factor
        predictions = []
        current_co2 = tree_data['CO2 Absorption (kg/year)'].values[0]
        decrease_factor = tree_data['CO2 Decrease After Years (kg)'].values[0] if 'CO2 Decrease After Years (kg)' in tree_data.columns else 0
        
        for year in range(1, years+1):
            # Apply decrease factor (simple linear decrease for demonstration)
            predicted_co2 = max(0, current_co2 - (decrease_factor * year))
            predictions.append(predicted_co2)
        
        return predictions
    except Exception as e:
        st.error(f"Error in CO2 prediction: {str(e)}")
        return None

def recommend_best_trees(soil_data, weather_data, tree_df, kmeans, scaler, features):
    """Recommend trees based on current conditions"""
    try:
        # Prepare input data
        current_temp = weather_data['temperature'] if weather_data else 25.0
        current_humidity = {'Low': 0, 'Moderate': 1, 'High': 2}.get(soil_data['soil_Humidity'], 1)
        
        input_data = {
            'Temp_avg': current_temp,
            'Humidity_encoded': current_humidity
        }
        
        # Add soil type
        soil_type = soil_data['soil_Type'].replace(' ', '_')
        for feat in features:
            if feat.startswith('Soil_'):
                input_data[feat] = 1 if soil_type.lower() in feat.lower() else 0
        
        # Create input DataFrame
        input_df = pd.DataFrame([input_data])[features]
        
        # Scale and predict cluster
        input_scaled = scaler.transform(input_df)
        cluster = kmeans.predict(input_scaled)[0]
        
        # Get trees from matching cluster
        recommended = tree_df[tree_df['Cluster'] == cluster].copy()
        
        # Score trees based on how well they match conditions
        def score_tree(row):
            score = 0
            # Temperature match (closer is better)
            temp_diff = abs(row['Temp_avg'] - current_temp)
            score += 1 - (temp_diff / 20)  # Normalize by max possible difference
            
            # Humidity match (exact match preferred)
            if row['Humidity_encoded'] == current_humidity:
                score += 1
            
            # Soil match (exact match preferred)
            soil_cols = [col for col in features if col.startswith('Soil_')]
            for col in soil_cols:
                if input_data[col] == 1 and row[col] == 1:
                    score += 1
                    break
            
            return score
        
        recommended['Match_Score'] = recommended.apply(score_tree, axis=1)
        recommended['Match_Percentage'] = (recommended['Match_Score'] / 3 * 100).round(0)
        
        # Return top 10 best matches
        return recommended.sort_values('Match_Score', ascending=False).head(10)
    
    except Exception as e:
        st.error(f"Error in recommendation: {str(e)}")
        return pd.DataFrame()

# =================================================================
# MAIN APPLICATION
# =================================================================
@login_required
def main_app():
    st.set_page_config(layout="wide")
    st.title("🌳 Smart Tree Recommendation & CO2 Sequestration System")
    
    # Initialize session states
    if 'analyses' not in st.session_state:
        st.session_state.analyses = []
    if 'last_draw' not in st.session_state:
        st.session_state.last_draw = None
    if 'selected_tree' not in st.session_state:
        st.session_state.selected_tree = None
    if 'show_co2_prediction' not in st.session_state:
        st.session_state.show_co2_prediction = False
    
    # User info
    user = st.session_state.user
    st.sidebar.markdown(f"**Logged in as:** {user['username']}")
    if st.sidebar.button("Logout"):
        logout()
    
    # Location input
    st.sidebar.header("Location Input")
    location = st.sidebar.text_input("Location Name")
    
    # Initialize map
    m = folium.Map(location=[20, 77], zoom_start=5)
    draw = Draw(export=True)
    draw.add_to(m)
    MiniMap().add_to(m)
    
    # Display map
    st.subheader("Select Location on Map")
    map_data = st_folium(m, width=1200, height=500)
    
    # Store drawing
    if map_data.get("last_active_drawing"):
        st.session_state.last_draw = map_data["last_active_drawing"]
    
    # Load CO2 data and model
    co2_df, le_family_co2, le_species_co2, le_soil_co2, le_humidity_co2 = load_co2_data()
    gbm_co2, mse_co2, co2_features = train_co2_model(co2_df) if co2_df is not None else (None, None, None)
    
    # Load tree data for recommendations
    tree_df, kmeans, scaler, features = load_and_cluster_tree_data()
    
    # Analyze button
    if st.sidebar.button("Analyze Location & Recommend Trees"):
        with st.spinner("Analyzing location and finding best trees..."):
            try:
                # Get coordinates
                if st.session_state.last_draw:
                    geom = st.session_state.last_draw["geometry"]
                    if geom["type"] == "Point":
                        lat, lon = geom["coordinates"][1], geom["coordinates"][0]
                    else:
                        coords = np.array(geom["coordinates"][0])
                        lat, lon = np.mean(coords[:, 1]), np.mean(coords[:, 0])
                elif location:
                    geolocator = Nominatim(user_agent="tree-app")
                    loc = geolocator.geocode(location)
                    if not loc:
                        raise ValueError("Location not found")
                    lat, lon = loc.latitude, loc.longitude
                else:
                    raise ValueError("Please draw on map or enter location name")
                
                # Get soil and weather data
                soil_data = get_soil_data(lat, lon)
                weather_data = get_weather_data(lat, lon)
                
                # Calculate NDVI and land health
                ndvi = calculate_ndvi(lat, lon)
                health_status, status_color, bg_color = get_land_health_status(ndvi)
                
                # Display land health status with colored card
                st.markdown(f"""
                <div style="border: 2px solid {status_color}; border-radius: 8px; padding: 16px; margin: 12px 0; background-color: {bg_color};">
                    <h3 style="color:{status_color}; margin-top:0;">LAND HEALTH: <strong>{health_status}</strong></h3>
                    <p><strong>NDVI Index:</strong> {ndvi:.2f} (Normalized Difference Vegetation Index)</p>
                    <p><strong>Interpretation:</strong> {get_ndvi_interpretation(ndvi)}</p>
                </div>
                """, unsafe_allow_html=True)
                
                # Display current conditions
                st.subheader("🌍 Current Conditions")
                cols = st.columns(3)
                with cols[0]:
                    st.metric("Soil Type", soil_data['soil_Type'])
                    st.metric("Soil Humidity", soil_data['soil_Humidity'])
                with cols[1]:
                    temp = weather_data['temperature'] if weather_data else "N/A"
                    st.metric("Temperature", f"{temp}°C")
                with cols[2]:
                    humidity = weather_data['humidity'] if weather_data else "N/A"
                    st.metric("Humidity", f"{humidity}%")
                
                # Get recommendations
                recommendations = recommend_best_trees(soil_data, weather_data, tree_df, kmeans, scaler, features)
                
                # Display recommendations
                st.subheader("🌿 Top Recommended Tree Species")
                if not recommendations.empty:
                    # Show top 3 best matches with improved card design
                    st.write("### Best Matches")
                    top_cols = st.columns(3)
                    card_colors = ["#4CAF50", "#8BC34A", "#CDDC39"]  # Green color palette
                    
                    for i, (_, row) in enumerate(recommendations.head(3).iterrows()):
                        with top_cols[i]:
                            st.markdown(f"""
                            <div style="border: 2px solid {card_colors[i]}; border-radius: 10px; padding: 15px; margin: 10px 0; background-color: #f8f9fa;">
                                <h4 style="color: {card_colors[i]};">{row['Accepted name']}</h4>
                                <p style="color: #333;"><strong>Family:</strong> {row['Family']}</p>
                                <p style="color: #333;"><strong>Ideal Temp:</strong> {row['Temp_avg']:.1f}°C</p>
                                <p style="color: #333;"><strong>Humidity:</strong> {['Low', 'Moderate', 'High'][int(row['Humidity_encoded'])]}</p>
                                <div style="background-color: #e0e0e0; border-radius: 5px; height: 20px; margin: 10px 0;">
                                    <div style="background-color: {card_colors[i]}; width: {row['Match_Percentage']}%; height: 100%; border-radius: 5px; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">
                                        {int(row['Match_Percentage'])}%
                                    </div>
                                </div>
                            </div>
                            """, unsafe_allow_html=True)
                    
                    # Show full table of recommendations
                    st.write("### All Recommended Species")
                    st.dataframe(
                        recommendations[['Accepted name', 'Family', 'Temp_avg', 'Humidity_encoded', 'Match_Percentage']]
                        .rename(columns={
                            'Accepted name': 'Species',
                            'Temp_avg': 'Ideal Temp (°C)',
                            'Humidity_encoded': 'Humidity Pref',
                            'Match_Percentage': 'Match %'
                        }),
                        column_config={
                            "Humidity Pref": st.column_config.SelectboxColumn(
                                "Humidity Preference",
                                options=["Low", "Moderate", "High"],
                                required=True
                            ),
                            "Match %": st.column_config.ProgressColumn(
                                "Match %",
                                format="%d%%",
                                min_value=0,
                                max_value=100
                            )
                        },
                        hide_index=True,
                        use_container_width=True
                    )
                    
                    # Store recommendations for CO2 prediction
                    st.session_state.recommendations = recommendations
                    st.session_state.show_co2_prediction = True
                else:
                    st.warning("No suitable trees found for these conditions")
                    st.session_state.show_co2_prediction = False
                
                # Save analysis
                st.session_state.analyses.append({
                    'location': location or f"{lat:.4f}, {lon:.4f}",
                    'time': datetime.now(),
                    'ndvi': ndvi,
                    'health_status': health_status,
                    'recommendations': recommendations
                })
                
            except Exception as e:
                st.error(f"Analysis failed: {str(e)}")
                st.session_state.show_co2_prediction = False
    
    # CO2 Prediction Section - Only show after analysis and tree selection
    if st.session_state.get('show_co2_prediction', False) and 'recommendations' in st.session_state:
        st.subheader("📈 CO2 Sequestration Prediction")
        
        # Select a tree for CO2 prediction
        selected_species = st.selectbox(
            "Select a tree species for CO2 sequestration prediction",
            options=st.session_state.recommendations['Accepted name'].unique()
        )
        
        if st.button("Predict CO2 Sequestration"):
            with st.spinner("Calculating CO2 sequestration..."):
                try:
                    # Get the selected tree data
                    selected_tree = st.session_state.recommendations[
                        st.session_state.recommendations['Accepted name'] == selected_species
                    ].iloc[0]
                    
                    # Get soil data (use last analyzed location)
                    if st.session_state.analyses:
                        last_analysis = st.session_state.analyses[-1]
                        if 'location' in last_analysis:
                            try:
                                # Prepare input for CO2 prediction
                                input_data = pd.DataFrame([{
                                    'Tree Family Encoded': le_family_co2.transform([selected_tree['Family']])[0],
                                    'Scientific Name Encoded': le_species_co2.transform([selected_species])[0],
                                    'Favourable temperature': selected_tree['Temp_avg'],
                                    'Soil Type Encoded': le_soil_co2.transform([soil_data['soil_Type']])[0],
                                    'Soil Humidity Encoded': le_humidity_co2.transform([soil_data['soil_Humidity']])[0],
                                    'Soil Temperature': soil_data['soil_Temp']
                                }])
                                
                                # Get base CO2 absorption
                                base_co2 = gbm_co2.predict(input_data[co2_features])[0]
                                
                                # Create a copy of selected tree data for prediction
                                prediction_data = selected_tree.to_frame().T
                                prediction_data['CO2 Absorption (kg/year)'] = base_co2
                                prediction_data['CO2 Decrease After Years (kg)'] = 2.0  # Default decrease factor
                                
                                # Predict for next 5 years
                                co2_predictions = predict_co2_sequestration(gbm_co2, prediction_data)
                                
                                if co2_predictions:
                                    # Display results
                                    st.subheader(f"CO2 Sequestration Forecast for {selected_species}")
                                    
                                    # Create a DataFrame for visualization
                                    years = [f"Year {i+1}" for i in range(5)]
                                    pred_df = pd.DataFrame({
                                        'Year': years,
                                        'CO2 Absorption (kg)': co2_predictions
                                    })
                                    
                                    # Show table
                                    st.dataframe(pred_df.set_index('Year'), use_container_width=True)
                                    
                                    # Show chart
                                    fig, ax = plt.subplots(figsize=(10, 5))
                                    sns.lineplot(data=pred_df, x='Year', y='CO2 Absorption (kg)', marker='o', ax=ax)
                                    ax.set_title(f"5-Year CO2 Sequestration Forecast for {selected_species}")
                                    ax.set_ylabel("CO2 Absorption (kg)")
                                    ax.grid(True)
                                    st.pyplot(fig)
                            except Exception as e:
                                st.error(f"Error in CO2 prediction for {selected_species}: {str(e)}")
                
                except Exception as e:
                    st.error(f"Error in CO2 prediction: {str(e)}")
    
    # Data exploration section
    st.header("Data Exploration")
    
    if co2_df is not None:
        # CO2 absorption distribution
        st.subheader("CO2 Absorption Distribution")
        fig3, ax3 = plt.subplots(figsize=(10, 5))
        sns.histplot(co2_df['CO2 Absorption (kg/year)'], bins=20, kde=True, ax=ax3)
        ax3.set_xlabel("CO2 Absorption (kg/year)")
        ax3.set_ylabel("Count")
        st.pyplot(fig3)
        
        # Top CO2 absorbing trees
        st.subheader("Top CO2 Absorbing Trees")
        top_co2 = co2_df.sort_values('CO2 Absorption (kg/year)', ascending=False).head(10)
        st.dataframe(top_co2[['Tree Family', 'Scientific Name', 'CO2 Absorption (kg/year)']], 
                    hide_index=True, use_container_width=True)

def get_ndvi_interpretation(ndvi):
    """Return interpretation text for NDVI value"""
    if ndvi > 0.6:
        return "Dense vegetation, very healthy land suitable for most plants"
    elif ndvi > 0.3:
        return "Moderate vegetation, land may need some improvement"
    else:
        return "Sparse vegetation, degraded land that needs restoration"

# =================================================================
# APP ROUTING
# =================================================================
def login_page():
    st.title("🌱 Tree Recommendation System Login")
    with st.form("login_form"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        if st.form_submit_button("Login"):
            user = authenticate_user(username, password)
            if user:
                st.session_state.user = user
                st.success(f"Welcome, {user['username']}!")
                time.sleep(1)
                st.rerun()
            else:
                st.error("Invalid credentials")

def logout():
    if 'user' in st.session_state:
        del st.session_state.user
    st.rerun()

def main():
    if 'user' not in st.session_state:
        login_page()
    else:
        main_app()

if __name__ == "__main__":
    main()
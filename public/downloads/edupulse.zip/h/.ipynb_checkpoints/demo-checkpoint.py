import streamlit as st
import folium
from folium.plugins import Draw
from geopy.geocoders import Nominatim
import pandas as pd
from datetime import datetime
import json
from streamlit_folium import st_folium
import matplotlib.pyplot as plt
import numpy as np
import contextily as ctx
from io import BytesIO
import requests

# Initialize CSV file
CSV_FILE = 'professional_land_analysis.csv'
try:
    df = pd.read_csv(CSV_FILE)
except FileNotFoundError:
    df = pd.DataFrame(columns=[
        'Location', 'Latitude', 'Longitude',
        'Status', 'NDVI', 'Area_Acres', 'Timestamp', 'Analysis_Type'
    ])

# Streamlit UI
st.title("🌱 Professional Land Analysis Tool")

# Mode selection
current_mode = st.radio(
    "Analysis Mode:",
    ["Draw Area Analysis", "Location Point Analysis"],
    horizontal=True
)

# Initialize map
m = folium.Map(location=[20, 77], zoom_start=5)
Draw(export=True, draw_options={
    'polygon': True, 'polyline': False, 'rectangle': False,
    'circle': False, 'marker': False, 'circlemarker': False
}).add_to(m)

# Display map and capture drawing events
map_output = st_folium(m, width=700, height=500)

# Location input (only for point mode)
location_name = ""
if current_mode == "Location Point Analysis":
    location_name = st.text_input("Enter Location:", placeholder="E.g., Mumbai, India")

# Analyze button
if st.button("Analyze Land", type="primary"):
    st.session_state.analysis_result = None
    try:
        if current_mode == "Draw Area Analysis":
            if not map_output.get("last_active_drawing"):
                st.error("Please draw an area first!")
                st.stop()
            
            # Simulate NDVI analysis (replace with actual API call)
            mean_ndvi = np.random.uniform(0, 0.8)  # Mock value
            area_acres = 250  # Mock value
            
            # Get polygon coordinates
            geom = map_output["last_active_drawing"]["geometry"]
            coords = geom["coordinates"][0]
            centroid = [sum(y for x, y in coords)/len(coords), 
                       sum(x for x, y in coords)/len(coords)]
            
        else:  # Location Point Analysis
            if not location_name:
                st.error("Please enter a location!")
                st.stop()
                
            # Geocode location
            geolocator = Nominatim(user_agent="land-analysis")
            location = geolocator.geocode(location_name)
            if not location:
                st.error("Location not found!")
                st.stop()
                
            # Simulate analysis
            mean_ndvi = np.random.uniform(0, 0.8)  # Mock value
            area_acres = 150  # Mock value
            centroid = [location.latitude, location.longitude]
            
            # Add marker to map
            folium.CircleMarker(
                location=centroid,
                radius=10,
                color='blue',
                fill=True
            ).add_to(m)

        # Determine land status (same logic as original)
        if mean_ndvi > 0.4:
            status = "Healthy Ecosystem 🌳"
            color = '#00AA00'
        elif 0.2 < mean_ndvi <= 0.4:
            status = "Moderate Land ⚠️"
            color = '#FFA500'
        else:
            status = "Degraded Land 🔥"
            color = '#FF0000'

        # Save results
        result = {
            'Location': location_name or "Drawn Area",
            'Latitude': centroid[0],
            'Longitude': centroid[1],
            'Status': status,
            'NDVI': round(mean_ndvi, 3),
            'Area_Acres': round(area_acres, 2),
            'Timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'Analysis_Type': current_mode
        }
        
        df = pd.concat([df, pd.DataFrame([result])], ignore_index=True)
        df.to_csv(CSV_FILE, index=False)
        
        # Display results
        st.success("Analysis Complete!")
        st.markdown(f"""
        <div style="background:{color}22; border-left:5px solid {color}; padding:15px; border-radius:4px">
            <h3 style="color:{color}; margin-top:0">{status}</h3>
            <div style="display:grid; grid-template-columns:auto auto; gap:10px">
                <div style="font-weight:bold">Location:</div>
                <div>{result['Location']}</div>
                <div style="font-weight:bold">Mean NDVI:</div>
                <div>{result['NDVI']}</div>
                <div style="font-weight:bold">Natural Area:</div>
                <div>{result['Area_Acres']} acres</div>
            </div>
            <hr style="border-color:{color}33">
            <div style="font-size:0.9em; color:#555">
                Analysis timestamp: {result['Timestamp']}
            </div>
        </div>
        """, unsafe_allow_html=True)
        
    except Exception as e:
        st.error(f"Analysis failed: {str(e)}")

# Clear button
if st.button("Clear Analysis"):
    st.session_state.clear_map = True
    st.experimental_rerun()

# Instructions
st.markdown("""
### How to Use:
1. **Select analysis mode** above
2. **Draw an area** or **enter location**
3. Click **Analyze Land**
4. View results below the map

**Legend:**
- 🌳 Healthy Ecosystem (NDVI > 0.4)
- ⚠️ Moderate Land (0.2 < NDVI ≤ 0.4)
- 🔥 Degraded Land (NDVI ≤ 0.2)
""")